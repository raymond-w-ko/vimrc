Custom built gvim.exe - supports ruby plugins with Ruby 1.9.2.
Contains patches 1-89 for vim 7.3.

Installation
----
Backup gvim.exe in vim install dir. Replace it with the gvim.exe from this zip.

Compiled libraries
----
Perl 5.12.1.0 - http://strawberry-perl.googlecode.com/files/strawberry-perl-5.12.1.0.msi
Python 2.7.3 - http://python.org/ftp/python/2.7.1/python-2.7.1.msi
Ruby 1.9.2
    http://rubyforge.org/frs/download.php/72170/rubyinstaller-1.9.2-p0.exe
    http://github.com/downloads/oneclick/rubyinstaller/DevKit-tdm-32-4.5.1-20101214-1400-sfx.exe

:version output
----
VIM - Vi IMproved 7.3 (2010 Aug 15, compiled Dec 26 2010 13:13:27)
MS-Windows 32-bit GUI version with OLE support
Included patches: 1-89
Compiled by arun@codito-win
Big version with GUI.  Features included (+) or not (-):
+arabic +autocmd +balloon_eval +browse ++builtin_terms +byte_offset +cindent 
+clientserver +clipboard +cmdline_compl +cmdline_hist +cmdline_info +comments 
+conceal +cryptv +cscope +cursorbind +cursorshape +dialog_con_gui +diff 
+digraphs -dnd -ebcdic +emacs_tags +eval +ex_extra +extra_search +farsi 
+file_in_path +find_in_path +float +folding -footer +gettext/dyn -hangul_input 
+iconv/dyn +insert_expand +jumplist +keymap +langmap +libcall +linebreak 
+lispindent +listcmds +localmap -lua +menu +mksession +modify_fname +mouse 
+mouseshape +multi_byte_ime/dyn +multi_lang -mzscheme +netbeans_intg +ole 
-osfiletype +path_extra +perl/dyn +persistent_undo -postscript +printer 
-profile +python/dyn +python3/dyn +quickfix +reltime +rightleft +ruby/dyn 
+scrollbind +signs +smartindent -sniff +startuptime +statusline -sun_workshop 
+syntax +tag_binary +tag_old_static -tag_any_white -tcl -tgetent -termresponse 
+textobjects +title +toolbar +user_commands +vertsplit +virtualedit +visual 
+visualextra +viminfo +vreplace +wildignore +wildmenu +windows +writebackup 
-xfontset -xim -xterm_save -xpm_w32 
   system vimrc file: "$VIM\vimrc"
     user vimrc file: "$HOME\_vimrc"
 2nd user vimrc file: "$VIM\_vimrc"
      user exrc file: "$HOME\_exrc"
  2nd user exrc file: "$VIM\_exrc"
  system gvimrc file: "$VIM\gvimrc"
    user gvimrc file: "$HOME\_gvimrc"
2nd user gvimrc file: "$VIM\_gvimrc"
    system menu file: "$VIMRUNTIME\menu.vim"
Compilation: gcc -Iproto -DWIN32 -DWINVER=0x0400 -D_WIN32_WINNT=0x0400 -DHAVE_PATHDEF -DFEAT_BIG 
-DHAVE_GETTEXT -DHAVE_LOCALE_H -DDYNAMIC_GETTEXT -DFEAT_OLE -DFEAT_CSCOPE -DFEAT_NETBEANS_INTG 
-DFEAT_GUI_W32 -DFEAT_CLIPBOARD -DFEAT_MBYTE -DFEAT_MBYTE_IME -DDYNAMIC_IME -DDYNAMIC_ICONV -pipe -w 
-march=i386 -Wall -IC:strawberryperl/lib/Core -DFEAT_PERL -LC:strawberryperl/lib/Core -DDYNAMIC_PERL 
-DDYNAMIC_PERL_DLL="perl512.dll" -DFEAT_RUBY -I c:\ruby192/lib/ruby/1.9.1/i386-mingw32 -I 
c:\ruby192/include/ruby-1.9.1 -I c:\ruby192/include/ruby-1.9.1/i386-mingw32 -DDYNAMIC_RUBY 
-DDYNAMIC_RUBY_DLL="msvcrt-ruby191.dll" -DDYNAMIC_RUBY_VER=191 -DFEAT_PYTHON  -DDYNAMIC_PYTHON 
-DFEAT_PYTHON3  -DDYNAMIC_PYTHON3  -O3 -fomit-frame-pointer -freg-struct-return -s
Linking: gcc -Iproto -DWIN32 -DWINVER=0x0400 -D_WIN32_WINNT=0x0400 -DHAVE_PATHDEF -DFEAT_BIG 
-DHAVE_GETTEXT -DHAVE_LOCALE_H -DDYNAMIC_GETTEXT -DFEAT_OLE -DFEAT_CSCOPE -DFEAT_NETBEANS_INTG 
-DFEAT_GUI_W32 -DFEAT_CLIPBOARD -DFEAT_MBYTE -DFEAT_MBYTE_IME -DDYNAMIC_IME -DDYNAMIC_ICONV -pipe -w 
-march=i386 -Wall -IC:strawberryperl/lib/Core -DFEAT_PERL -LC:strawberryperl/lib/Core -DDYNAMIC_PERL 
-DDYNAMIC_PERL_DLL="perl512.dll" -DFEAT_RUBY -I c:\ruby192/lib/ruby/1.9.1/i386-mingw32 -I 
c:\ruby192/include/ruby-1.9.1 -I c:\ruby192/include/ruby-1.9.1/i386-mingw32 -DDYNAMIC_RUBY 
-DDYNAMIC_RUBY_DLL="msvcrt-ruby191.dll" -DDYNAMIC_RUBY_VER=191 -DFEAT_PYTHON  -DDYNAMIC_PYTHON 
-DFEAT_PYTHON3  -DDYNAMIC_PYTHON3  -O3 -fomit-frame-pointer -freg-struct-return -s -mwindows -o gvim.exe -lkernel32

